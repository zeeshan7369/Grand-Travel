<footer>
    <section class="footer footer_w3layouts_section_1its py-5">
        <div class="container py-lg-4 py-3">
            <div class="row footer-top">
                <div class="col-lg-3 col-sm-6 footer-grid_section_1its_w3">
                    <div class="footer-title">
                        <h3>Address</h3>
                    </div>
                    <div class="footer-text">
                        <p>Location : Daviet Punjab, Bihar, Delhi, United States</p>
                        <p>Phone : +91 7369878132</p>
                        <p>Email : <a href="mailto:zeeshansiddiquie3@gmail.com">zeeshansiddiquie3@gmail.com</a></p>
                        <p>Fax : +12 534894364</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 footer-grid_section mt-sm-0 mt-4">
                    <div class="footer-title">
                        <h3>About Us</h3>
                    </div>
                    <div class="footer-text">
                    <p>
            We provide lots of services for our travellers !<br />
            Its our responsibilities to give good services
          </p>
                    </div>
                    <ul class="social_section_1info">
                        <li class="mb-2 facebook"><a href="https://www.facebook.com/shakih.siddiquie.3"><span class="fa fa-facebook"></span></a></li>
                        <li class="mb-2 twitter"><a href="https://x.com/ZSiddiquie21997?t=PEDVL90p8dUJ6-PScEayig&s=09"><span class="fa fa-twitter"></span></a></li>
                        <li class="google"><a href="https://instagram.com/__zeeshu__.13?igshid=MzRlODBiNWFlZA=="><span class="fa fa-instagram"></span></a></li>
                        <li class="linkedin"><a href="https://www.linkedin.com/in/zeeshan-siddiquie-921979255"><span class="fa fa-linkedin"></span></a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 mt-lg-0 mt-4 footer-grid_section_1its_w3">
                    <div class="footer-title">
                        <h3>Travel Places</h3>
                    </div>
                    <div class="row">
                        <ul class="col-6 links">
                            <li><a href="#choose" class="scroll">New Zealand </a></li>
                            <li><a href="#overview" class="scroll">Paris, France </a></li>
                            <li><a href="#pricing" class="scroll">Los Angles</a></li>
                            <li><a href="#faq" class="scroll"> Darlington</a></li>
                            <li><a href="#testimonials" class="scroll">Canada </a></li>
                            <li><a href="#contact" class="scroll"> South Africa </a></li>
                        </ul>
                        <ul class="col-6 links">
                            <li><a href="#">Spain </a></li>
                            <li><a href="#">Turkey </a></li>
                            <li><a href="#faq" class="scroll">Europe </a></li>
                            <li><a href="#">Italy </a></li>
                            <li><a href="#">Sweden </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mt-lg-0 mt-4 footer-grid_section_1its_w3">
                    <div class="footer-title">
                        <h3>Newsletter</h3>
                    </div>
                    <div class="footer-text">
                        <p>By subscribing to our mailing list you will always get latest news and updates from us.</p>
                        <form action="#" method="post">
                            <input type="email" name="Email" placeholder="Enter your email..." required="">
                            <button class="btn1"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                            <div class="clearfix"> </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer>
<!-- //footer -->

<!-- copyright -->
<div class="copyright py-3 text-center">
    <p>© 2023 Grand Tour. All Rights Reserved | Design by <a href="#" target="=_blank"> Zeeshan</a></p>
</div>
<!-- //copyright -->

<!-- move top -->
<div class="move-top text-right">
    <a href="#home" class="move-top">
        <span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
    </a>
</div>

