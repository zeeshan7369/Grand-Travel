<?php session_start();

unset($_SESSION['user']);
echo "
<script>
    window.location.assign('register.php?msg=Successfully Logout');
</script>
";
