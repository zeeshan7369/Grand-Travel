<?php 

$obj = mysqli_connect("localhost","root","","o7800");