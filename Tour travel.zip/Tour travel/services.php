
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Grand Tour Travel Category Flat Bootstrap Responsive Web Template | Services :: w3layouts</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Grand Tour Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

	<script>
		addEventListener("load", function() {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>

	<!-- css files -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
	<link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
	<link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<!-- //google fonts -->

</head>

<body>

	<!-- header -->
	<?php
	include_once("header.php");
	?>
	<!-- //header -->

	<!-- banner -->
	<section class="banner_inner" id="home">
		<div class="banner_inner_overlay">
		</div>
	</section>
	<!-- //banner -->

	<!-- services -->
	<section class="services pt-5">
		<div class="container py-lg-5 py-sm-3">
			<h2 class="heading text-capitalize text-center mb-lg-5 mb-4"> Our Services</h2>
			<div class="row">
				<div class="col-lg-3 main-title-text">
					<h4 class="my-lg-4 mb-4">The journey of a thousand miles begins with a single step.</h4>
					<img src="images/p1.jpg" alt="" class="img-fluid" />
				</div>
				<div class="col-lg-9 mt-lg-0 mt-5">
					<div class="row">
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-building" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Accomodation</h4>
									<p>Comfortable lodging in scenic locales, ranging from cozy inns to luxurious resorts, ensuring a restful retreat.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-free-code-camp" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Winter Tours</h4>
									<p>Snowy escapes, cozy cabins, and frosty adventures await on our unforgettable winter tours. Embrace the chill!</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-users" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Exp Agents</h4>
									<p>Seasoned tour agent: Craft unforgettable journeys, handle logistics, and ensure seamless travel experiences for clients.</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-money" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Low Prices</h4>
									<p>Unbeatable tour prices, your passport to affordable adventures and unforgettable experiences. Don't miss out!</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-binoculars" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Easy Booking</h4>
									<p>"Discover, book, and enjoy unforgettable tours with our user-friendly platform, making travel experiences effortless."</p>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-sm-6 service-grid-wthree text-center mb-5">
							<div class="ser-fashion-grid">
								<div class="about-icon mb-md-4 mb-3">
									<span class="fa fa-camera" aria-hidden="true"></span>
								</div>
								<div class="ser-sevice-grid">
									<h4 class="pb-3">Best Packages</h4>
									<p>Unforgettable adventures await in our all-inclusive tour package. Explore, indulge, and create lasting memories today!</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //services -->

	<!-- text -->
	<section class="text-content">
		<div class="overlay-inner py-5">
			<div class="container py-md-3">
				<div class="test-info">
					<h4 class="tittle">Enjoy The Trip</h4>
					<p class="mt-3">Indulge in a captivating journey with our carefully curated tours. Immerse yourself in unique cultures, savor delicious cuisine, and explore breathtaking landscapes. Let us take care of the details while you enjoy an unforgettable adventure. Create cherished memories and relish the trip of a lifetime with us.</p>
					<div class="text-left mt-4">
						<a href="booking.php">Book Now</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //text -->

	<!-- places -->
	<section class="trav-grids py-5" id="desti">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="heading text-capitalize text-center mb-lg-5 mb-4">Tourism Places</h3>
			<div class="row">
				<div class="col-lg-6 mt-4">
					<div class="grids-tem-one">
						<div class="row">
							<div class="col-sm-5 grids-img-left">
								<img src="images/japan.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-sm-7 right-cont">
								<h4 class="mb-2 let mt-sm-0 mt-2 tm-clr">Japan</h4>
								<ul class="d-flex">
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
								</ul>
								<p class="mt-3">Japan offers a blend of tradition and modernity, with stunning landscapes, historic temples, and vibrant cities.</p>
								<p class="duration mt-2"><span class="fa fa-clock-o mr-2"></span><strong>Duration</strong> : 2 Days, 5hrs</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6 mt-4">
					<div class="grids-tem-one">
						<div class="row">
							<div class="col-sm-5 grids-img-left">
								<img src="images/singapore.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-sm-7 right-cont">
								<h4 class="mb-2 let mt-sm-0 mt-2 tm-clr">Singapore</h4>
								<ul class="d-flex">
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
								</ul>
								<p class="mt-3">Singapore: A dynamic city-state with stunning gardens, diverse cuisine, and futuristic architecture.</p>
								<p class="duration mt-2"><span class="fa fa-clock-o mr-2"></span><strong>Duration</strong> : 2 Days, 3hrs</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row pt-lg-3">
				<div class="col-lg-6 mt-4">
					<div class="grids-tem-one">
						<div class="row">
							<div class="col-sm-5 grids-img-left">
								<img src="images/malaysia.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-sm-7 right-cont">
								<h4 class="mb-2 let mt-sm-0 mt-2 tm-clr">Malaysia</h4>
								<ul class="d-flex">
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
								</ul>
								<p class="mt-3">Malaysia: Blend of diverse cultures, pristine beaches, lush rainforests, and vibrant cities.</p>
								<p class="duration mt-2"><span class="fa fa-clock-o mr-2"></span><strong>Duration</strong> : 1 Days, 10hrs</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6 mt-4">
					<div class="grids-tem-one">
						<div class="row">
							<div class="col-sm-5 grids-img-left">
								<img src="images/china.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-sm-7 right-cont">
								<h4 class="mb-2 mt-sm-0 mt-2 let tm-clr">China</h4>
								<ul class="d-flex">
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
									<li><span class="fa fa-star"></span></li>
								</ul>
								<p class="mt-3">China offers the Great Wall, Terracotta Army, Forbidden City, and diverse landscapes.</p>
								<p class="duration mt-2"><span class="fa fa-clock-o mr-2"></span><strong>Duration</strong> : 0 Days, 8hrs</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //places -->

	<!--footer -->
	<?php
	include_once("footer.php");
	?>
	<!--footer -->


</body>

</html>