<?php session_start();

include "config.php";
$email = $_REQUEST['email'];
$password = $_REQUEST['password'];
$q = "select * from user where email='$email' and password='$password'";
$res = mysqli_query($obj,$q);
if($row = mysqli_fetch_array($res)){
    $_SESSION['user'] = $email;

}
echo "
<script>
    window.location.assign('showalluser.php');
</script>
";
