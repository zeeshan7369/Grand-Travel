<!DOCTYPE html>
<html lang="en">

<head>
	<title>Booking</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Grand Tour Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

	<script>
		addEventListener("load", function() {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>

	<!-- css files -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
	<link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
	<link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->

	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<!-- //google fonts -->

	<!-- bootstrap css -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	<!-- bootstrap css -->

</head>

<body>

	<!-- header -->
	<?php
	include_once("header.php");
	?>
	<!-- //header -->

	<!-- banner -->
	<section class="banner_inner" id="home">
		<div class="banner_inner_overlay">
		</div>
	</section>
	<!-- //banner -->

	<?php
	include_once("config.php");
	?>
	<!-- Booking -->
	<section class="contact py-5">
		<div class="container py-lg-5 py-sm-4">
			<h2 class="heading text-capitalize text-center mb-lg-5 mb-4"> Book Your Tour</h2>
			<div class="contact-grids">
				<div class="row">
					<div class="col-lg-7 contact-left-form">
						<!-- php start -->
						<?php
					
						if (isset($_POST['sub'])) {
							$id = $_REQUEST['id'];
							$name = $_REQUEST['name'];
							$email = $_REQUEST['email'];
							$phone = $_REQUEST['phone'];
							$date = $_REQUEST['date'];
							$adult = $_REQUEST['adult'];
							$kids = $_REQUEST['kids'];
							$source = $_REQUEST['source'];
							$destination = $_REQUEST['destination'];
							$check = $_REQUEST['check'];
							$guide = $_REQUEST['guide'];
							include "config.php";
							$q = "insert into tour values('$id','$name','$email','$phone','$date','$adult','$kids','$source','$destination','$check','$guide')";
							$res = mysqli_query($con, $q);
							if ($res > 0) {
								echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
												<strong>Booked Successfully</strong> 
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>';
							} else {
								echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
												<strong>Error in Booking</strong> 
												<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
											</div>' . mysqli_error($con);
							}
						}
						?>
						<!-- php end -->
						<form action="booking.php" method="post" class="row">
							<div class="col-sm-6 form-group contact-forms">
								<input type="text" name="name" id="name" class="form-control" placeholder="Name" required="" autocomplete="off">
							</div>
							<div class="col-sm-6 form-group contact-forms">
								<input type="email" name="email" id="email" class="form-control" placeholder="Email" required="" autocomplete="off">
							</div>
							<div class="col-sm-6 form-group contact-forms">
								<input type="number" name="phone" id="phone" class="form-control" placeholder="Phone" required="" autocomplete="off">
							</div>
							<div class="col-sm-6 form-group contact-forms">
								<input type="datetime-local" name="date" id="date" class="form-control" placeholder="Date" required="" autocomplete="off">
							</div>
							<div class="col-sm-6 form-group contact-forms">
								<select class="form-control" name="adult" id="adults">
									<option>Adults</option>
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
									<option>5 or more</option>
								</select>
							</div>
							<div class="col-sm-6 form-group contact-forms">
								<select class="form-control" name="kids" id="kids">
									<option>Kids</option>
									<option>0</option>
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
									<option>5 or more</option>
								</select>
							</div>
							<div class="col-md-6 form-group contact-forms">

								<input type="text" class="form-control" name="source" id="source" placeholder="Source" name="source" autocomplete="off" />
							</div>

							<div class="col-md-6 form-group contact-forms">

								<input type="text" name="destination" id="destination" class="form-control" placeholder="Destination" autocomplete="off" />
							</div>


							<div class="col-md-6 form-group contact-forms">
								<input type="checkbox" name="check" id="check" value="Senior_citizen" />
								<label for="vehicle1">Are you Senior citizen. If yes please check</label><br />
								<select name="guide" id="guide">
									<h3>Choose your Taker.</h3>
									<option>Select Your guide person</option>
									<option>Aamir khan</option>
									<option>Brijesh Giri</option>
									<option>Prince Kumar</option>
									<option>Zeeshan</option>
									<option>Al Farukh</option>
									<option>Reyaz</option>
									<option>Shoaib</option>
									<option>Mozamill</option>
								</select>
							</div>


							<div class="col-md-12 booking-button">
								<button class="btn btn-block sent-butnn" name="sub">Book Now</button>
							</div>
						</form>
					</div>
					<div class="col-lg-5 contact-right pl-lg-5">

						<div class="image-tour position-relative">
							<img src="images/banner1.jpg" alt="" class="img-fluid" />
							<p><span class="fa fa-tags"></span> <span>RS 8000 - 15% off</span></p>
						</div>

						<h4>Tour Description</h4>
						<p class="mt-3">Explore breathtaking landscapes and immerse yourself in rich cultural experiences on our guided tour. Discover hidden gems, savor local cuisine, and create lasting memories. From historic landmarks to natural wonders, our tour offers a perfect blend of adventure and relaxation. Join us for an unforgettable journey of a lifetime.</p>

					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //Booking -->

	<!-- bootstrap js -->
	<script>
		function checkfrm() {
			var name = document.getElementById("name").value;
			var email = document.getElementById("email").value;
			var phone = document.getElementById("phone").value;
			var date = document.getElementById("date").value;
			
			// var password = document.getElementById("password").value;
			var emailpatt = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var mobpatt = /^[0-9]{10,10}$/;

			if (name == "" || email == "" || phone == "") {
				alert("please fill form");
				return false;
			}
			if (!emailpatt.test(email)) {
				alert('Please enter valid email id');
				return false;
			}
			if (!mobpatt.test(phone)) {
				alert('Please enter 10 digit valid Phone number');
				return false;
			}

		}
	</script>
	<!-- bootstrap js end -->

	<!--footer -->
	<?php
	include_once("footer.php");
	?>
	<!--footer -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
<!--/script-->
<script src="assets\js\lightbox-plus-jquery.js"> </script>
<!--/script-->

</body>

</html>