

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Hotels a Hotels Category Responsive Web Template | Home : W3layouts</title>

    <link href="//fonts.googleapis.com/css?family=Spartan:400,500,600,700,900&display=swap" rel="stylesheet">

    <!--google font   -->
    <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&display=swap" rel="stylesheet">
    <!--icons bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
                        
    <link rel="stylesheet" href="assets/css/new-col.css">


    <!--<link rel="stylesheet" href="assets/css/lightbox.css">-->

    <link rel="stylesheet" href="assets/css/lightbox.min.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  

    <!--register-->

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: cursive;
        }

        section {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100vh;
            position: fixed;
            /* background-color: #ffffff; */
            background-image: url(images/reg\ bgc.jpg);
        }

        .register-box {
            position: relative;
            width: 450px;
            height: 550px;
            background: #ced4da;
            border: 4px solid #800080;
            border-radius: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(15px);
            overflow: hidden;
        }
        .register-box .icon-close{
            position: absolute;
            top: 0;
            right: 0;
            width: 45px;
            height: 35px;
            background: #000;
            font-size: 2em;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            border-bottom-left-radius: 20px;
            cursor: pointer;
            z-index: 1;
        }
        .register-box .icon-close a{
        text-decoration: none;
            color: #fff;
        }

        h2 {
            font-size: 2em;
            color: #000;
            text-align: center;
            margin-bottom: 20px;
        }

        .input-box {
            position: relative;
            width: 350px;
            margin: 30px 0;
            border-bottom: 2px solid #000;
            font-weight: 600;
        }

        .input-box label {
            position: absolute;
            top: 50%;
            left: 5px;
            transform: translateY(-50%);
            font-size: 1em;
            color: #000;
            pointer-events: none;
            transition: .5s;
        }
        .input-box input:focus~label,
        .input-box input:valid~label {
            top: -5px;
        }
        .input-box input {
            width: 100%;
            height: 50px;
            background: transparent;
            border: none;
            outline: none;
            font-size: 1em;
            color: #000;
            padding: 0 35px 0 5px;
        }
        .input-box .icon {
            position: absolute;
            right: 8px;
            color: #000;
            font-size: 1.2em;
            line-height: 57px;
        }
        .buttonn {
            width: 100%;
            height: 40px;
            background: #000;
            border: none;
            outline: none;
            border-radius: 40px;
            cursor: pointer;
            font-size: 1em;
            color: #fff;
            font-weight: 500;
        }

        .buttonn:hover{
            background:#fff;
            color: #000;
        }

        .login-link {
            font-size: .9em;
            color: #000;
            text-align: center;
            margin: 25px 0 10px;
        }

        .login-link p a {
            position: relative;
            color: blueviolet;
            text-decoration: none;
            font-weight: 800;
        }

        .login-link p a::after {
            content: ' ';
            position: absolute;
            left: 0;
            bottom: -3px;
            width: 100%;
            height: 2px;
            background: blueviolet;
            border-radius: 5px;
            transform-origin: right;
            transform: scaleX(0);
            transition: transform .5s;
        }

        .login-link p a:hover::after {
            transform-origin: left;
            transform: scaleX(1);
        }

        @media(max-width: 360px) {
            .login-box {
                width: 100%;
                height: 100vh;
                border: none;
                border-radius: 0;
            }

            .input-box {
                width: 290px;
            }
        }
    </style>

  </head>


<body>

<section>
    <div class="register-box mx-3">
        <span class="icon-close">
            <a href="index.php" style="margin: 0;"> <ion-icon name="close"><i class="bi bi-x "></i></ion-icon></a>
        </span>
        <?php 
            if(isset($_POST['sub'])){
                $name = $_REQUEST['name'];
                $email = $_REQUEST['email'];
                // $phone = $_REQUEST['phone'];
                $password = sha1(md5($_REQUEST['password']));
                include "config.php";
                $q = "insert into login values(NULL,'$name','$email','$password')";
                $res = mysqli_query($con,$q);
                if($res>0){
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Register Successfully</strong> 
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';  
                }
                else{
                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Issue in Register</strong> 
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>' .mysqli_error($con);  
                }
            }
        ?>
        <form action="register1.php"  method="post">
            <h2>REGISTER</h2>
            <div class="input-box">
                <span class="icon">
                    <ion-icon name="person"><i class="bi bi-person-fill"></i></ion-icon>
                </span>
                <input type="text"  name="name" id="name" required>
                <label>Name</label>
            </div>
            <div class="input-box">
                <span class="icon">
                    <ion-icon name="mail"><i class="bi bi-envelope-fill"></i></ion-icon>
                </span>
                <input type="email" name="email" id="email" required>
                <label>Email</label>
            </div>
            <!-- <div class="input-box">
                <span class="icon">
                    <ion-icon name="lock-closed"><i class="bi bi-telephone-fill"></i></ion-icon>
                </span>
                <input type="number" name="phone" id="phone" required>
                <label>Phone</label>
            </div> -->
            <div class="input-box">
                <span class="icon">
                    <ion-icon name="lock-closed"><i class="bi bi-lock-fill"></i></ion-icon>
                </span>
                <input type="password"name="password" id="password"  required>
                <label>Password</label>
            </div>

            <input type="submit"  class="buttonn" name="sub" onclick="return checkfrm()" value="Submit">
            <div class="login-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
        </form>
    </div>
</section>



<script>
    function checkfrm(){
        var name=document.getElementById("name").value;
        var email=document.getElementById("email").value;
        var phone=document.getElementById("phone").value;
        var password=document.getElementById("password").value;
        var emailpatt=/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        var mobpatt=/^[0-9]{10,10}$/;

        if(name=="" || email=="" || phone=="" ||password==""){
            alert("please fill form");
            return false;
        }
        if(!emailpatt.test(email)){
            alert('Please enter valid email id');
            return false; 
        }
        if(!mobpatt.test(phone)){
            alert('Please enter 10 digit valid Phone number');
            return false;
        }

    }
</script>








<!--register form
<div class="container">
    <div class="row">
        <div class="col-3"></div>
        <div class="col-md-6  bor m-2 bg-secondary">
            <?php /*
                if(isset($_POST['sub'])){
                    $name = $_REQUEST['name'];
                    $email = $_REQUEST['email'];
                    $phone = $_REQUEST['phone'];
                    $password = sha1(md5($_REQUEST['password']));
                    include "config.php";
                    $q = "insert into register values('$email','$name','$phone','$password')";
                    $res = mysqli_query($con,$q);
                    if($res>0){
                        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Register Successfully</strong> 
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>';  
                    }
                    else{
                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Issue in Register</strong> 
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>' .mysqli_error($con);  
                    }
                }*/
            ?>
                <form action="register.php" class="bg-white p-3" method="post">
                    <h2 style="text-align:center;" class="colll  p-2 bbb ">Register Form</h2><br />
                    <div class="row mb-3">
                        <label for="name" class="col-sm-4 col-form-label"><i class="bi bi-person-fill"></i> Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control border border-dark border-bottom" name="name" id="name">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="email" class="col-sm-4 col-form-label"><i class="bi bi-envelope-fill"></i> Email</label>
                        <div class="col-sm-8">
                            <input type="email" class="form-control border border-dark" name="email" id="email">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="phone" class="col-sm-4 col-form-label"><i class="bi bi-telephone-fill"></i> Phone</label>
                        <div class="col-sm-8">
                            <input type="number" class="form-control border border-dark" name="phone" id="phone">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="password" class="col-sm-4 col-form-label"><i class="bi bi-lock-fill"></i> Password</label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control border border-dark" name="password" id="password">
                        </div>
                    </div>
                    <div class="d-grid gap-2 col-6 mx-auto mb-3">
                        <input type="submit"  class="btn fw-bold colll bbb" name="sub" onclick="return checkfrm()" value="Submit">
                    </div>
                    <div class="row mb-3 text-center m-3">
                        <p> Already have an account <a href="login.php" class="licol">ClickHere</a></p>
                    </div>
                </form>
        </div>
        <div class="col-3"></div>
     </div>
</div>
    
<script>
    function checkfrm(){
        name=document.getElementById("name").value;
        email=document.getElementById("email").value;
        phone=document.getElementById("phone").value;
        password=document.getElementById("password").value;

        if(name=="" || email=="" || phone=="" ||password==""){
            alert("please fill form");
            return false;
        }
    }
</script> -->



 <!--footer-->

        <!-- bootstrap js -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
        <!--bootstrapjs-->
        
  >
        
    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>

    <script src="assets/js/owl.carousel.js"></script>
    <!-- script for banner slider-->
    <script>
        $(document).ready(function () {
            $('.owl-one').owlCarousel({
                loop: true,
                margin: 0,
                nav: false,
                responsiveClass: true,
                autoplay: false,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script -->

    <!-- script for owlcarousel -->
    <script>
        $(document).ready(function () {
            $('.owl-testimonial').owlCarousel({
                loop: true,
                margin: 0,
                nav: true,
                responsiveClass: true,
                autoplay: false,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script for owlcarousel -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

            $('.popup-with-move-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-slide-bottom'
            });
        });
    </script>


    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- disable body scroll which navbar is in active -->

   <script src="assets/js/bootstrap.min.js"></script>

     <!--bootstrap js 
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    -->

<!--/script-->
<script src="assets\js\lightbox-plus-jquery.js"> </script>
<!--/script-->
</body>

</html>