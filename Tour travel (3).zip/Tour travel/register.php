<?php
include_once("header.php");
?>

<div class="container-fluid bg-info p-4">
    <div class="row">
        <div class="col-md-6 p-5">
            <h3 class="display-4" style="margin-top: .5rem;">Register As A User</h3>
            <?php
            if (isset($_POST['sub'])) {
                $name = $_REQUEST['name'];
                $email = $_REQUEST['email'];
                $password = $_REQUEST['password'];
                include "config.php";
                $q = "insert into login values(NULL,'$name','$email','$password')";
                $res = mysqli_query($obj, $q);
                if ($res > 0) {
                    echo '
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>User Register Sucessfully</strong> 
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
                }
            }
            ?>
            <form action="register.php" method="post">
                <table class="table table-bordered">
                    <tr>
                        <td>Name</td>
                        <td>
                            <input type="text" name="name" class="form-control" id="name" required>
                        </td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </td>
                    </tr>
                    <tr>
                        <td>password</td>
                        <td>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </td>
                    </tr>
                    <tr>
                        <td> </td>
                        <td>
                            <input type="submit" name="sub" value="Register" class="btn btn-danger">
                        </td>
                    </tr>
                </table>
            </form>

        </div>
        <div class="col-md-6 p-5" style="margin-top: .5rem;">
            <h3 class="display-4">
                Login
            </h3>
            
            <form action="logincheck.php" method="post" style="margin-top: .5rem;">
                <table class="table table-bordred" >
                    <tr>
                        <td>
                            Email
                        </td>
                        <td>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            password
                        </td>
                        <td>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" name="subb" value="Login button" class="btn btn-danger">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>

<?php
include_once "footer.php";
?>