<?php session_start();

unset($_SESSION['login']);
echo "
<script>
    window.location.assign('index.php?msg=Successfully Logout');
</script>
";
