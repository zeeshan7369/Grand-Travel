
<?php session_start(); ?>


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Hotels a Hotels Category Responsive Web Template | Home : W3layouts</title>

    <link href="//fonts.googleapis.com/css?family=Spartan:400,500,600,700,900&display=swap" rel="stylesheet">

    <!--google font   -->
    <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&display=swap" rel="stylesheet">
    <!--icons bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
                        
    <link rel="stylesheet" href="assets/css/new-col.css">


    <!--<link rel="stylesheet" href="assets/css/lightbox.css">-->

    <link rel="stylesheet" href="assets/css/lightbox.min.css">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  

    <!-- login-->

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: cursive;
    }

    .sec {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100vh;
        /* background-color: #ffff; */
        background-image: url(images/login\ bgc.jpg);
    }

    .login-box {
        position: relative;
        width: 400px;
        height: 450px;
        background: #ced4da;
        border: 4px solid #800080;
        border-radius: 20px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(15px);
        overflow: hidden;
    }

    .login-box .icon-close {
        position: absolute;
        top: 0;
        right: 0;
        width: 45px;
        height: 35px;
        background: #000;
        font-size: 2em;
        color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        border-bottom-left-radius: 20px;
        cursor: pointer;
        z-index: 1;
    }
    .login-box .icon-close a{
        text-decoration: none;
        color: #fff;
    }

    .log {
        font-size: 2em;
        color: #000;
        text-align: center;
    }

    .input-box {
        position: relative;
        width: 310px;
        margin: 30px 0;
        border-bottom: 2px solid #000;
    }

    .input-box label {
        position: absolute;
        top: 50%;
        left: 5px;
        transform: translateY(-50%);
        font-size: 1em;
        color: #000;
        pointer-events: none;
        transition: .5s;
    }

    .input-box input:focus~label,
    .input-box input:valid~label {
        top: -5px;
    }

    .input-box input {
        width: 100%;
        height: 50px;
        background: transparent;
        border: none;
        outline: none;
        font-size: 1em;
        color: #000;
        padding: 0 35px 0 5px;
    }

    .input-box .icon {
        position: absolute;
        right: 8px;
        color: #000;
        font-size: 1.2em;
        line-height: 57px;
    }

    .remember-forget {
        margin: -15px 0 15px;
        font-size: .9em;
        color: #000;
        display: flex;
        justify-content: space-between;
    }

    .remember-forget label input {
        margin-right: 3px;
    }

    .remember-forget a {
        position: relative;
        color: blueviolet;
        text-decoration: none;
        font-weight: 600;
    }

    .remember-forget  a::after {
        content: ' ';
        position: absolute;
        left: 0;
        bottom: -3px;
        width: 100%;
        height: 2px;
        background: blueviolet;
        border-radius: 5px;
        transform-origin: right;
        transform: scaleX(0);
        transition: transform .5s;
    }

    .remember-forget a:hover::after {
        transform-origin: left;
        transform: scaleX(1);
    }

    .buttonn {
        width: 100%;
        height: 40px;
        background: #000;
        border: none;
        outline: none;
        border-radius: 40px;
        cursor: pointer;
        font-size: 1em;
        color: #fff;
        font-weight: 500;
    }
    .buttonn:hover{
        background:#fff;
        color: #000;
    }

    .register-link {
        font-size: .9em;
        color: #000;
        text-align: center;
        margin: 25px 0 10px;
    }

    .register-link p a {
        position: relative;
        color: blueviolet;
        text-decoration: none;
        font-weight: 600;
    }
    .register-link p a::after {
        content: ' ';
        position: absolute;
        left: 0;
        bottom: -3px;
        width: 100%;
        height: 2px;
        background: blueviolet;
        border-radius: 5px;
        transform-origin: right;
        transform: scaleX(0);
        transition: transform .5s;
    }

    .register-link p a:hover::after {
        transform-origin: left;
        transform: scaleX(1);
    }


    @media(max-width: 360px) {
        .login-box {
            width: 100%;
            height: 100vh;
            border: none;
            border-radius: 0;
        }

        .input-box {
            width: 290px;
        }
    }
</style>


  </head>


<body>
  

<!--login form-->


<section class="sec">
    <div class="login-box">
        <span class="icon-close">
            <a href="index.php" style="margin: 0;"><ion-icon name="close"><i class="bi bi-x "></i></ion-icon></a>
        </span>
        <?php 
            if(isset($_REQUEST['msg'])){
                echo "<p class='alert alert-info'>$_REQUEST[msg]</p>";
            }
        ?>
        <?php 
                if(isset($_POST['sub'])){
                    $email = $_REQUEST['email'];
                    $password = sha1(md5($_REQUEST['password']));
                    include "config.php";
                    $q = "select * from login where email='$email' and password='$password' ";
                    $res = mysqli_query($con,$q);
                    if($row = mysqli_fetch_array($res)){
                        $_SESSION['login'] = $email;
                        $_SESSION['name'] = $row['name'];
                        echo "
                        <script>
                            window.location.assign('index.php');
                        </script>
                        ";
                    }
                    else{
                        echo '<div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                            <strong>Username or password not correct</strong> 
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>' .mysqli_error($con);     
                    }
                }
            ?>
        <form action="login.php" method="post" >
            <h2 class="log">LOGIN</h2>
            <div class="input-box">
                <span class="icon">
                    <ion-icon name="mail"><i class="bi bi-envelope-fill"></i> </ion-icon>
                </span>
                <input type="email" id="email" name="email" required>
                <label for="email">Email</label>
            </div>
            <div class="input-box">
                <span class="icon">
                    <ion-icon name="lock-closed"><i class="bi bi-lock-fill"></i></ion-icon>
                </span>
                <input type="password" id="password" name="password" required>
                <label for="password">Password</label>
            </div>
            <div class="remember-forget">
                <label><input type="checkbox">Remember me</label>
                <a href="#">Forgot Password</a>
            </div>
            <input type="submit" name="sub" class="buttonn" onclick="return checkfrom()" value="Login">
            <div class="register-link">
                <p>Don't have an account? <a href="register1.php">Register</a></p>
            </div>
        </form>
    </div>
</section>
 
<!--
<div class="container">
    <div class="row">
        <div class="col-3"></div>
        <div class="col-md-6 col-lg-6 col-12 bor m-2 p-2 bg-secondary">
            <span class="icon-close">
                <a href="index.html" style="margin: 0;"><ion-icon name="close"></ion-icon></a>
            </span>
            <?php /*
                if(isset($_POST['sub'])){
                    $email = $_REQUEST['email'];
                    $password = sha1(md5($_REQUEST['password']));
                    include "config.php";
                    $q = "select * from register where email='$email' and password='$password' ";
                    $res = mysqli_query($con,$q);
                    if($row = mysqli_fetch_array($res)){
                        $_SESSION['user'] = $email;
                        $_SESSION['name'] = $row['name'];
                        echo "
                        <script>
                            window.location.assign('index.php');
                        </script>
                        ";
                    }
                    else{
                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Username or password not correct</strong> 
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>' .mysqli_error($con);     
                    }
                }*/
            ?>
            <form action="login.php" class="bg-white p-3 m-2" method="post">
                <?php /*
                    if(isset($_REQUEST['msg'])){
                        echo "<p class='alert alert-info'>$_REQUEST[msg]</p>";
                    }*/
                ?>
                <h2 style="text-align:center;" class="colll p-2 bbb "><i class="bi bi-person-circle"></i> Login Form</h2><br />
                <div class="row mb-5">
                    <label for="email" class="col-sm-4 col-form-label"><i class="bi bi-envelope-fill"></i> Email</label>
                    <div class="col-sm-8">
                        <input type="email" class="form-control border border-dark"  name="email"id="email" >
                    </div>
                </div>
                <div class="row mb-4">
                    <label for="password" class="col-sm-4 col-form-label"><i class="bi bi-lock-fill"></i> Password</label>
                    <div class="col-sm-8">
                        <input type="password" class="form-control border border-dark" name="password" id="password">
                    </div>
                </div>
                <div class="d-grid gap-2 col-6 mx-auto mb-3">
                    <input type="submit" name="sub" class="btn colll fw-bold bbb" onclick="return checkfrom()" value="Login">
                </div>
                <div class="row mb-3 text-center m-3">
                    <p> Need an account <a href="register.php" class="licol">Click Here</a></p>
               </div>
            </form>
        </div>
        <div class="col-3"></div>
    </div>
</div> -->
    
<script>
    function checkform(){
        var email=document.getElementById("email").value;
        var password=document.getElementById("password").value;
        var emailpatt=/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if(name=="" || email=="" || phone=="" ||password==""){
            alert("please enter info");
            return false;
        }
        if(!emailpatt.test(email)){
            alert('Please enter valid email id');
            return false; 
        }

    }
</script>



 <!--footer-->


    <section class="w3l-footer-29-main w3l-copyright">

        <!--footer-->
        <!-- bootstrap js -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
        <!--bootstrapjs-->
        
        <!-- move top -->
        <button onclick="topFunction()" id="movetop" title="Go to top">
            &#10548;
        </button>
        <script>
            // When the user scrolls down 20px from the top of the document, show the button
            window.onscroll = function () {
                scrollFunction()
            };

            function scrollFunction() {
                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                    document.getElementById("movetop").style.display = "block";
                } else {
                    document.getElementById("movetop").style.display = "none";
                }
            }

            // When the user clicks on the button, scroll to the top of the document
            function topFunction() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
        </script>
        <!-- /move top -->
    </section>

    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>

    <script src="assets/js/owl.carousel.js"></script>
    <!-- script for banner slider-->
    <script>
        $(document).ready(function () {
            $('.owl-one').owlCarousel({
                loop: true,
                margin: 0,
                nav: false,
                responsiveClass: true,
                autoplay: false,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script -->

    <!-- script for owlcarousel -->
    <script>
        $(document).ready(function () {
            $('.owl-testimonial').owlCarousel({
                loop: true,
                margin: 0,
                nav: true,
                responsiveClass: true,
                autoplay: false,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    667: {
                        items: 1,
                        nav: true
                    },
                    1000: {
                        items: 1,
                        nav: true
                    }
                }
            })
        })
    </script>
    <!-- //script for owlcarousel -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

            $('.popup-with-move-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-slide-bottom'
            });
        });
    </script>


    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- disable body scroll which navbar is in active -->

   <script src="assets/js/bootstrap.min.js"></script>

     <!--bootstrap js 
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    -->

<!--/script-->
<script src="assets\js\lightbox-plus-jquery.js"> </script>
<!--/script-->
</body>

</html>
