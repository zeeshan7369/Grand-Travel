<?php
    include "header.php";
?>
<div class="w3l-open-block-services py-5">
		<div class="container py-lg-5 pt-4">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="card text-center">
						<div class="icon-holder">
							<span class="fa fa-signal service-icon" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Dental Bridge</h4>
						<div class="open-description">
							<p>Maecenas sodales eu commodo ligula eget dolor dolor sit amet ligula</p>
							<a href="#read">Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-md-0 mt-5 pt-md-0 pt-3">
					<div class="card text-center">
						<div class="icon-holder">
							<span class="fa fa-assistive-listening-systems service-icon" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Dental Implant</h4>
						<div class="open-description">
							<p>Maecenas sodales eu commodo ligula eget dolor dolor sit amet ligula</p>
							<a href="#read">Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-lg-0 mt-5 pt-lg-0 pt-3">
					<div class="card text-center">
						<div class="icon-holder">
							<span class="fa fa-diamond service-icon" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Dental Crowns</h4>
						<div class="open-description">
							<p>Maecenas sodales eu commodo ligula eget dolor dolor sit amet ligula</p>
							<a href="#read">Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 mt-lg-0 mt-5 pt-lg-0 pt-3">
					<div class="card text-center">
						<div class="icon-holder">
							<span class="fa fa-magic service-icon" aria-hidden="true"></span>
						</div>
						<h4 class="mission">Teeth Whitening</h4>
						<div class="open-description">
							<p>Maecenas sodales eu commodo ligula eget dolor dolor sit amet ligula</p>
							<a href="#read">Read More</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //services block3 -->

<?php
    include "footer.php";
?>