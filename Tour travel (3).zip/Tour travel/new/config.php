<?php 

$obj = mysqli_connect("localhost","root","","project_t");
?>