<?php 
    include "header.php";
?>
<!-- main-slider -->
<section class="w3l-main-slider" id="home">
		<div class="banner-content">
			<div class="owl-one owl-carousel owl-theme">
				<div class="item">
					<li>
						<div class="slider-info banner-view bg bg2">
							<div class="banner-info">
								<div class="container">
									<div class="banner-info-bg">
										<h6>Dental care for life</h6>
										<h5>Experience, trust and proven success
										</h5>
										<a class="btn mt-sm-5 mt-4" href="services.html">View Our Services</a>
									</div>
								</div>
							</div>
						</div>
					</li>
				</div>
				<div class="item">
					<li>
						<div class="slider-info  banner-view banner-top1 bg bg2">
							<div class="banner-info">
								<div class="container">
									<div class="banner-info-bg">
										<h6>Care for your smile</h6>
										<h5>Get all the essential
											dental care today</h5>
										<a class="btn mt-sm-5 mt-4" href="services.html">View Our Services</a>
									</div>
								</div>
							</div>
						</div>
					</li>
				</div>
				<div class="item">
					<li>
						<div class="slider-info banner-view banner-top2 bg bg2">
							<div class="banner-info">
								<div class="container">
									<div class="banner-info-bg">
										<h6>Dental care for life</h6>
										<h5>Experience, trust and proven success
										</h5>
										<a class="btn mt-sm-5 mt-4" href="services.html">View Our Services</a>
									</div>
								</div>
							</div>
						</div>
					</li>
				</div>
				<div class="item">
					<li>
						<div class="slider-info banner-view banner-top3 bg bg2">
							<div class="banner-info">
								<div class="container">
									<div class="banner-info-bg">
										<h6>Care for your smile </h6>
										<h5>Get all the essential
											dental care today</h5>
										<a class="btn mt-sm-5 mt-4" href="services.html">View Our Services</a>
									</div>
								</div>
							</div>
						</div>
					</li>
				</div>
			</div>
			<ul class="slide-social-icons list-unstyled">
				<li class="share">Share On : </li>
				<li>
					<a href="#" class="w3pvt_facebook">
						<span class="fa fa-facebook-f"></span>
					</a>
				</li>
				<li>
					<a href="#" class="w3pvt_twitter">
						<span class="fa fa-twitter"></span>
					</a>
				</li>
				<li>
					<a href="#" class="w3pvt_dribble">
						<span class="fa fa-dribbble"></span>
					</a>
				</li>
				<li>
					<a href="#" class="w3pvt_google">
						<span class="fa fa-google-plus"></span>
					</a>
				</li>
			</ul>
		</div>

	</section>
	<!-- /main-slider -->
<?php 
    include "footer.php";
?>