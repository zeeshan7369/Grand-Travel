<?php include "header.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Admin Page</h2>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>