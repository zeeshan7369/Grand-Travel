<?php session_start();
if (isset($_POST['subb'])) {
    include "config.php";
    $email = $_REQUEST['email'];
    $password = $_REQUEST['password'];
    $q = "select * from login where email='$email' and password='$password'";
    $res = mysqli_query($con,$q);
    if($row = mysqli_fetch_array($res))
    {
        $_SESSION['login'] = $email;
        $_SESSION['name'] = $row['name'];
        header('Location: index.php');
    }
    else
    {
        header('Location: index.php');
        
    }
}
?>