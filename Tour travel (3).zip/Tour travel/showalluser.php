<?php include "header.php"; ?>
<?php include "config.php";



?>

<div class="container-fluid bg-info p-4">
    <div class="row">
        <div class="col-md-6 p-5">
            <table class="table table-bordered table-hover">
                <tr>
                    <th>Name</th>
                    <th>Eamil</th>
                    <th>Password</th>

                </tr>
                <?php
                $q = "select * from login";
                $result = mysqli_query($con, $q);
                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td>$row[name]</td>";
                    echo "<td>$row[email]</td>";
                    echo "<td>$row[password]</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>